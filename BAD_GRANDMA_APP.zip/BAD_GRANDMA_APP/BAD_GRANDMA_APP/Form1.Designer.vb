﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnGoogle = New System.Windows.Forms.Button()
        Me.btnPaint = New System.Windows.Forms.Button()
        Me.btnNotepad = New System.Windows.Forms.Button()
        Me.btnMusic = New System.Windows.Forms.Button()
        Me.btnAdobe = New System.Windows.Forms.Button()
        Me.btnShotCut = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(-4, -1)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(822, 518)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'btnGoogle
        '
        Me.btnGoogle.BackColor = System.Drawing.Color.LightSalmon
        Me.btnGoogle.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnGoogle.Font = New System.Drawing.Font("Verdana", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGoogle.Location = New System.Drawing.Point(12, 37)
        Me.btnGoogle.Name = "btnGoogle"
        Me.btnGoogle.Size = New System.Drawing.Size(220, 137)
        Me.btnGoogle.TabIndex = 1
        Me.btnGoogle.Text = "THE INTERNET"
        Me.btnGoogle.UseVisualStyleBackColor = False
        '
        'btnPaint
        '
        Me.btnPaint.BackColor = System.Drawing.Color.LightSalmon
        Me.btnPaint.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnPaint.Font = New System.Drawing.Font("Verdana", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPaint.Location = New System.Drawing.Point(12, 193)
        Me.btnPaint.Name = "btnPaint"
        Me.btnPaint.Size = New System.Drawing.Size(220, 137)
        Me.btnPaint.TabIndex = 2
        Me.btnPaint.Text = "PAINTING"
        Me.btnPaint.UseVisualStyleBackColor = False
        '
        'btnNotepad
        '
        Me.btnNotepad.BackColor = System.Drawing.Color.LightSalmon
        Me.btnNotepad.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnNotepad.Font = New System.Drawing.Font("Verdana", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNotepad.Location = New System.Drawing.Point(12, 356)
        Me.btnNotepad.Name = "btnNotepad"
        Me.btnNotepad.Size = New System.Drawing.Size(220, 137)
        Me.btnNotepad.TabIndex = 4
        Me.btnNotepad.Text = "NOTEPAD"
        Me.btnNotepad.UseVisualStyleBackColor = False
        '
        'btnMusic
        '
        Me.btnMusic.BackColor = System.Drawing.Color.LightSalmon
        Me.btnMusic.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnMusic.Font = New System.Drawing.Font("Verdana", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMusic.Location = New System.Drawing.Point(577, 37)
        Me.btnMusic.Name = "btnMusic"
        Me.btnMusic.Size = New System.Drawing.Size(220, 137)
        Me.btnMusic.TabIndex = 3
        Me.btnMusic.Text = "PLAY OLD SCHOOL MUSIC"
        Me.btnMusic.UseVisualStyleBackColor = False
        '
        'btnAdobe
        '
        Me.btnAdobe.BackColor = System.Drawing.Color.LightSalmon
        Me.btnAdobe.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnAdobe.Font = New System.Drawing.Font("Verdana", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdobe.Location = New System.Drawing.Point(577, 193)
        Me.btnAdobe.Name = "btnAdobe"
        Me.btnAdobe.Size = New System.Drawing.Size(220, 137)
        Me.btnAdobe.TabIndex = 6
        Me.btnAdobe.Text = "PHOTO EDITING"
        Me.btnAdobe.UseVisualStyleBackColor = False
        '
        'btnShotCut
        '
        Me.btnShotCut.BackColor = System.Drawing.Color.LightSalmon
        Me.btnShotCut.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnShotCut.Font = New System.Drawing.Font("Verdana", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnShotCut.Location = New System.Drawing.Point(577, 356)
        Me.btnShotCut.Name = "btnShotCut"
        Me.btnShotCut.Size = New System.Drawing.Size(220, 137)
        Me.btnShotCut.TabIndex = 5
        Me.btnShotCut.Text = "VIDEO EDITTING"
        Me.btnShotCut.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.BackColor = System.Drawing.Color.Red
        Me.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnClose.Location = New System.Drawing.Point(363, 482)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(75, 23)
        Me.btnClose.TabIndex = 7
        Me.btnClose.Text = "EXIT APP"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(809, 517)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnAdobe)
        Me.Controls.Add(Me.btnShotCut)
        Me.Controls.Add(Me.btnNotepad)
        Me.Controls.Add(Me.btnMusic)
        Me.Controls.Add(Me.btnPaint)
        Me.Controls.Add(Me.btnGoogle)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "Form1"
        Me.Text = "BAD GRANDMA"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnGoogle As Button
    Friend WithEvents btnPaint As Button
    Friend WithEvents btnNotepad As Button
    Friend WithEvents btnMusic As Button
    Friend WithEvents btnAdobe As Button
    Friend WithEvents btnShotCut As Button
    Friend WithEvents btnClose As Button
End Class
