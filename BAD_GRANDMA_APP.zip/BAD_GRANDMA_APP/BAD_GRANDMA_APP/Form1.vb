﻿Public Class Form1
    Private Sub btnGoogle_Click(sender As Object, e As EventArgs) Handles btnGoogle.Click
        Process.Start("C:\Program Files (x86)\Google\Chrome\Application\chrome.exe")
    End Sub

    Private Sub btnPaint_Click(sender As Object, e As EventArgs) Handles btnPaint.Click
        Process.Start("C:\WINDOWS\system32\mspaint.exe")

    End Sub

    Private Sub btnNotepad_Click(sender As Object, e As EventArgs) Handles btnNotepad.Click
        Process.Start("C:\WINDOWS\system32\notepad.exe")
    End Sub



    Private Sub btnAdobe_Click(sender As Object, e As EventArgs) Handles btnAdobe.Click
        Process.Start("C:\Program Files (x86)\Adobe\Adobe Photoshop CS2\Photoshop.exe")

    End Sub

    Private Sub btnShotCut_Click(sender As Object, e As EventArgs) Handles btnShotCut.Click
        Process.Start("C:\Program Files\Shotcut\shotcut.exe")
    End Sub

    Private Sub btnMusic_Click(sender As Object, e As EventArgs) Handles btnMusic.Click
        Process.Start("C:\Program Files (x86)\Windows Media Player\wmplayer.exe")
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub
End Class
